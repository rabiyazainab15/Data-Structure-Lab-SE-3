#include <iostream>
using namespace std;

int linearSearch(int arr[], int size, int target, int index = 0) {
    if (index >= size) return -1; // not found
    if (arr[index] == target) return index;
    return linearSearch(arr, size, target, index + 1);
}

int main() {
    int arr[] = {5, 15, 25, 35, 45};
    int target;
    cout << "Enter number to search: ";
    cin >> target;

    int result = linearSearch(arr, 5, target);
    if (result != -1) cout << "Found at index " << result << endl;
    else cout << "Not found!" << endl;

    return 0;
}

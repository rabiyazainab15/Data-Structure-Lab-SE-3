#include <iostream>
using namespace std;

class QueueCount {
    int arr[10];
    int front, rear;
public:
    QueueCount() {
        front = -1;
        rear = -1;
    }

    void enqueue(int x) {
        if (rear == 9) {
            cout << "Queue Overflow! " <<endl;
            return;
        }
        if (front == -1) front = 0;
        arr[++rear] = x;
        cout << x << " enqueued. " <<endl;
    }

    void dequeue() {
        if (front == -1 || front > rear) {
            cout << "Queue Underflow! " <<endl;
            return;
        }
        cout << arr[front++] << " dequeued. " <<endl;
    }

    void countElements() {
        if (front == -1 || front > rear) {
            cout << "Queue is empty. " <<endl;
            return;
        }
        cout << "Number of elements in queue: " << (rear - front + 1) << endl;
    }
};

int main() {
    QueueCount q;
    int choice, val;
    do {
        cout << "\n--- Queue Count Menu --- " <<endl;
        cout << "1. Enqueue\n2. Dequeue\n3. Count Elements\n4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> val;
            q.enqueue(val);
            break;
        case 2:
            q.dequeue();
            break;
        case 3:
            q.countElements();
            break;
        case 4:
            cout << "Exiting... " <<endl;
            break;
        default:
            cout << "Invalid choice! " <<endl;
        }
    } while (choice != 4);

    return 0;
}

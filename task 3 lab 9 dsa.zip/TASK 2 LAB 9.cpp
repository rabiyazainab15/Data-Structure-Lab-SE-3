#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

class QueueLL {
    Node* front;
    Node* rear;
public:
    QueueLL() {
        front = rear = nullptr;
    }

    void enqueue(int x) {
        Node* temp = new Node();
        temp->data = x;
        temp->next = nullptr;
        if (rear == nullptr) {
            front = rear = temp;
        } else {
            rear->next = temp;
            rear = temp;
        }
        cout << x << " enqueued. " <<endl;
    }

    void dequeue() {
        if (front == nullptr) {
            cout << "Queue Underflow! " <<endl;
            return;
        }
        Node* temp = front;
        cout << front->data << " dequeued. " <<endl;
        front = front->next;
        if (front == nullptr) rear = nullptr;
        delete temp;
    }

    void display() {
        if (front == nullptr) {
            cout << "Queue is empty. " <<endl;
            return;
        }
        cout << "Queue elements: ";
        Node* temp = front;
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    QueueLL q;
    int choice, val;
    do {
        cout << " --- Linked List Queue Menu --- " <<endl;
        cout << "1. Enqueue\n2. Dequeue\n3. Display\n4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> val;
            q.enqueue(val);
            break;
        case 2:
            q.dequeue();
            break;
        case 3:
            q.display();
            break;
        case 4:
            cout << "Exiting... " <<endl;
            break;
        default:
            cout << "Invalid choice! " <<endl;
        }
    } while (choice != 4);

    return 0;
}

#include <iostream>
#define SIZE 5
using namespace std;

class Queue {
    int arr[SIZE];
    int front, rear;
public:
    Queue() {
        front = -1;
        rear = -1;
    }

    void enqueue(int x) {
        if (rear == SIZE - 1) {
            cout << "Queue Overflow! " <<endl;
            return;
        }
        if (front == -1) front = 0;
        arr[++rear] = x;
        cout << x << " enqueued. " <<endl;
    }

    void dequeue() {
        if (front == -1 || front > rear) {
            cout << "Queue Underflow! " <<endl;
            return;
        }
        cout << arr[front++] << " dequeued. " <<endl;
    }

    void display() {
        if (front == -1 || front > rear) {
            cout << "Queue is empty. " <<endl;
            return;
        }
        cout << "Queue elements: ";
        for (int i = front; i <= rear; i++) {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    Queue q;
    int choice, val;
    do {
        cout << " --- Menu --- " <<endl;
        cout << "1. Enqueue\n 2. Dequeue\n3. Display\n4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> val;
            q.enqueue(val);
            break;
        case 2:
            q.dequeue();
            break;
        case 3:
            q.display();
            break;
        case 4:
            cout << "Exiting... " <<endl;
            break;
        default:
            cout << "Invalid choice! " <<endl;
        }
    } while (choice != 4);

    return 0;
}
